package com.onlinehotelbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinehotelbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
