package com.onlinehotelbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.onlinehotelbooking.model.Seller;
import com.onlinehotelbooking.repository.SellerRepository;
@Service
public class SellerService {
	@Autowired
	private SellerRepository sellerRepository; 
	//this is the method to save a record of the seller
	public Seller saveSeller(Seller seller) {
		return sellerRepository.save(seller);
	}
	public List<Seller> getAllSellers(){
		return sellerRepository.findAll();
	}
	

}
