package com.onlinehotelbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlinehotelbooking.model.Seller;
import com.onlinehotelbooking.service.SellerService;

@RestController
@RequestMapping("/sellerapi")
public class SellerController {
	@Autowired
	private SellerService sellerService;
	@PostMapping
   public  ResponseEntity<Seller> createSeller(@RequestBody Seller seller) {
	   Seller sellerr=sellerService.saveSeller(seller);
	   return new ResponseEntity<>(sellerr,HttpStatus.CREATED);
   }
	@GetMapping("/all")
	public ResponseEntity<List<Seller>> getAllSellers() {
        List<Seller> sellers = sellerService.getAllSellers();
        return new ResponseEntity<>(sellers, HttpStatus.OK);
    }
}
